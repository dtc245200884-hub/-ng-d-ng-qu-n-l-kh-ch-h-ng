<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1">
    <title>404 - Không tìm thấy</title>
    <link rel="stylesheet" href="${pageContext.request.contextPath}/css/style.css">
</head>
<body>
<div class="container narrow" style="text-align:center">
    <div class="error-code">404</div>
    <h2>Không tìm thấy khách hàng</h2>
    <p>Khách hàng bạn yêu cầu không tồn tại hoặc đã bị xóa.</p>
    <a class="btn btn-primary" href="${pageContext.request.contextPath}/customers">Quay lại danh sách</a>
</div>
</body>
</html>
