<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Danh sách khách hàng</title>
    <link rel="stylesheet" href="${pageContext.request.contextPath}/css/style.css">
</head>
<body>
<div class="container">
    <h1>Danh sách khách hàng</h1>
    <p class="subtitle">Quản lý thông tin khách hàng trong hệ thống.</p>
    <div class="toolbar">
        <span>Tổng số khách hàng: <strong>${customers.size()}</strong></span>
        <a class="btn btn-success" href="${pageContext.request.contextPath}/customers?action=create">+ Thêm khách hàng</a>
    </div>
    <table>
        <thead><tr><th>Mã</th><th>Họ và tên</th><th>Email</th><th>Địa chỉ</th><th>Thao tác</th></tr></thead>
        <tbody>
        <c:forEach items="${customers}" var="customer">
            <tr>
                <td><c:out value="${customer.id}"/></td>
                <td><a href="${pageContext.request.contextPath}/customers?action=view&id=${customer.id}"><c:out value="${customer.name}"/></a></td>
                <td><c:out value="${customer.email}"/></td>
                <td><c:out value="${customer.address}"/></td>
                <td class="actions">
                    <a href="${pageContext.request.contextPath}/customers?action=view&id=${customer.id}">Xem</a>
                    <a href="${pageContext.request.contextPath}/customers?action=edit&id=${customer.id}">Sửa</a>
                    <a href="${pageContext.request.contextPath}/customers?action=delete&id=${customer.id}">Xóa</a>
                </td>
            </tr>
        </c:forEach>
        <c:if test="${empty customers}">
            <tr><td colspan="5">Chưa có khách hàng nào.</td></tr>
        </c:if>
        </tbody>
    </table>
</div>
</body>
</html>
