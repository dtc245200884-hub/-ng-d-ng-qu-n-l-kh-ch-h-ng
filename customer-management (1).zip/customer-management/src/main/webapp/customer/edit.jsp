<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Sửa khách hàng</title>
    <link rel="stylesheet" href="${pageContext.request.contextPath}/css/style.css">
</head>
<body>
<div class="container narrow">
    <h1>Cập nhật khách hàng</h1>
    <p class="subtitle">Chỉnh sửa thông tin khách hàng có mã <c:out value="${customer.id}"/>.</p>
    <form action="${pageContext.request.contextPath}/customers?action=edit" method="post">
        <input type="hidden" name="id" value="<c:out value='${customer.id}'/>">
        <div class="form-group"><label for="name">Họ và tên</label><input id="name" name="name" type="text" maxlength="100" value="<c:out value='${customer.name}'/>" required></div>
        <div class="form-group"><label for="email">Email</label><input id="email" name="email" type="email" maxlength="150" value="<c:out value='${customer.email}'/>" required></div>
        <div class="form-group"><label for="address">Địa chỉ</label><input id="address" name="address" type="text" maxlength="200" value="<c:out value='${customer.address}'/>" required></div>
        <div class="form-actions"><button class="btn btn-primary" type="submit">Lưu thay đổi</button><a class="btn btn-muted" href="${pageContext.request.contextPath}/customers">Hủy</a></div>
    </form>
</div>
</body>
</html>
