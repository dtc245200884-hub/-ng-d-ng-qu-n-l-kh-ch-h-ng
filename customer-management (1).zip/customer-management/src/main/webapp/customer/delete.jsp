<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Xác nhận xóa khách hàng</title>
    <link rel="stylesheet" href="${pageContext.request.contextPath}/css/style.css">
</head>
<body>
<div class="container narrow">
    <h1>Xác nhận xóa</h1>
    <div class="notice">Bạn có chắc chắn muốn xóa khách hàng này không? Thao tác này không thể hoàn tác.</div>
    <div class="detail-row"><div class="detail-label">Mã khách hàng</div><div><c:out value="${customer.id}"/></div></div>
    <div class="detail-row"><div class="detail-label">Họ và tên</div><div><c:out value="${customer.name}"/></div></div>
    <div class="detail-row"><div class="detail-label">Email</div><div><c:out value="${customer.email}"/></div></div>
    <div class="detail-row"><div class="detail-label">Địa chỉ</div><div><c:out value="${customer.address}"/></div></div>
    <form action="${pageContext.request.contextPath}/customers?action=delete" method="post">
        <input type="hidden" name="id" value="<c:out value='${customer.id}'/>">
        <div class="form-actions"><button class="btn btn-danger" type="submit">Đồng ý xóa</button><a class="btn btn-muted" href="${pageContext.request.contextPath}/customers">Hủy</a></div>
    </form>
</div>
</body>
</html>
