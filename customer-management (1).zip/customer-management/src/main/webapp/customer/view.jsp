<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Chi tiết khách hàng</title>
    <link rel="stylesheet" href="${pageContext.request.contextPath}/css/style.css">
</head>
<body>
<div class="container narrow">
    <h1>Chi tiết khách hàng</h1>
    <div class="detail-row"><div class="detail-label">Mã khách hàng</div><div><c:out value="${customer.id}"/></div></div>
    <div class="detail-row"><div class="detail-label">Họ và tên</div><div><c:out value="${customer.name}"/></div></div>
    <div class="detail-row"><div class="detail-label">Email</div><div><c:out value="${customer.email}"/></div></div>
    <div class="detail-row"><div class="detail-label">Địa chỉ</div><div><c:out value="${customer.address}"/></div></div>
    <div class="form-actions">
        <a class="btn btn-primary" href="${pageContext.request.contextPath}/customers?action=edit&id=${customer.id}">Sửa thông tin</a>
        <a class="btn btn-muted" href="${pageContext.request.contextPath}/customers">Quay lại danh sách</a>
    </div>
</div>
</body>
</html>
