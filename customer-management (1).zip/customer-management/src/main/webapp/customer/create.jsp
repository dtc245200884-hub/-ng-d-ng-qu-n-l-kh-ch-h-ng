<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Thêm khách hàng</title>
    <link rel="stylesheet" href="${pageContext.request.contextPath}/css/style.css">
</head>
<body>
<div class="container narrow">
    <h1>Thêm khách hàng mới</h1>
    <p class="subtitle">Nhập thông tin khách hàng bên dưới.</p>
    <form action="${pageContext.request.contextPath}/customers?action=create" method="post">
        <div class="form-group"><label for="name">Họ và tên</label><input id="name" name="name" type="text" maxlength="100" required></div>
        <div class="form-group"><label for="email">Email</label><input id="email" name="email" type="email" maxlength="150" required></div>
        <div class="form-group"><label for="address">Địa chỉ</label><input id="address" name="address" type="text" maxlength="200" required></div>
        <div class="form-actions"><button class="btn btn-success" type="submit">Lưu khách hàng</button><a class="btn btn-muted" href="${pageContext.request.contextPath}/customers">Hủy</a></div>
    </form>
</div>
</body>
</html>
