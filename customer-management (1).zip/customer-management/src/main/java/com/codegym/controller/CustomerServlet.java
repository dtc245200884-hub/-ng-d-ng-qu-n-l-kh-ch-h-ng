package com.codegym.controller;

import com.codegym.model.Customer;
import com.codegym.service.CustomerService;
import com.codegym.service.CustomerServiceImpl;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.util.List;

/** Điều phối các yêu cầu xem, thêm, sửa, xóa khách hàng. */
@WebServlet(name = "CustomerServlet", urlPatterns = "/customers")
public class CustomerServlet extends HttpServlet {
    private final CustomerService customerService = new CustomerServiceImpl();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        String action = request.getParameter("action");
        if (action == null || action.isBlank()) action = "list";

        switch (action) {
            case "create" -> forward(request, response, "customer/create.jsp");
            case "edit" -> showCustomerForm(request, response, "customer/edit.jsp");
            case "delete" -> showCustomerForm(request, response, "customer/delete.jsp");
            case "view" -> showCustomerForm(request, response, "customer/view.jsp");
            default -> listCustomers(request, response);
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        String action = request.getParameter("action");

        try {
            if ("create".equals(action)) {
                Customer customer = new Customer(0, request.getParameter("name"),
                        request.getParameter("email"), request.getParameter("address"));
                customerService.save(customer);
            } else if ("edit".equals(action)) {
                int id = Integer.parseInt(request.getParameter("id"));
                Customer customer = customerService.findById(id);
                if (customer == null) {
                    showNotFound(request, response);
                    return;
                }
                customer.setName(request.getParameter("name"));
                customer.setEmail(request.getParameter("email"));
                customer.setAddress(request.getParameter("address"));
                customerService.update(id, customer);
            } else if ("delete".equals(action)) {
                int id = Integer.parseInt(request.getParameter("id"));
                if (customerService.findById(id) == null) {
                    showNotFound(request, response);
                    return;
                }
                customerService.remove(id);
            }
            response.sendRedirect(request.getContextPath() + "/customers");
        } catch (NumberFormatException ex) {
            showNotFound(request, response);
        }
    }

    private void listCustomers(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        List<Customer> customers = customerService.findAll();
        request.setAttribute("customers", customers);
        forward(request, response, "customer/list.jsp");
    }

    private void showCustomerForm(HttpServletRequest request, HttpServletResponse response, String page)
            throws ServletException, IOException {
        try {
            int id = Integer.parseInt(request.getParameter("id"));
            Customer customer = customerService.findById(id);
            if (customer == null) {
                showNotFound(request, response);
                return;
            }
            request.setAttribute("customer", customer);
            forward(request, response, page);
        } catch (NumberFormatException ex) {
            showNotFound(request, response);
        }
    }

    private void showNotFound(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setStatus(HttpServletResponse.SC_NOT_FOUND);
        forward(request, response, "error-404.jsp");
    }

    private void forward(HttpServletRequest request, HttpServletResponse response, String page)
            throws ServletException, IOException {
        request.getRequestDispatcher("/" + page).forward(request, response);
    }
}
