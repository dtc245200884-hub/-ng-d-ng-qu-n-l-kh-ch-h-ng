# Customer Management (Java JSP/Servlet MVC)

Ứng dụng quản lý khách hàng dùng Java 17, Maven, JSP, Servlet Jakarta và JSTL; tương thích Apache Tomcat 10.1+.

## Chức năng
- Hiển thị danh sách khách hàng
- Thêm khách hàng
- Sửa thông tin khách hàng
- Xóa khách hàng (có trang xác nhận)
- Xem chi tiết khách hàng
- Trang báo lỗi khi không tìm thấy khách hàng

Dữ liệu mẫu được lưu trong `Map` tĩnh trong bộ nhớ. Dữ liệu sẽ trở về mặc định khi ứng dụng khởi động lại; đây chưa phải cơ sở dữ liệu thật.

## Chạy ứng dụng
1. Cài JDK 17, Maven và Apache Tomcat 10.1 trở lên.
2. Mở terminal tại thư mục có `pom.xml`.
3. Chạy:
   ```bash
   mvn clean package
   ```
4. Sau khi thấy `BUILD SUCCESS`, lấy file `target/customer-management.war`.
5. Sao chép WAR vào thư mục `webapps` của Tomcat rồi khởi động Tomcat.
6. Mở `http://localhost:8080/customer-management/customers`.

## Cấu trúc chính
- `model/Customer.java`: mô hình khách hàng
- `service/CustomerService.java`: hợp đồng xử lý dữ liệu
- `service/CustomerServiceImpl.java`: lưu dữ liệu giả lập bằng Map
- `controller/CustomerServlet.java`: điều hướng GET/POST tại `/customers`
- `src/main/webapp/customer`: các trang JSP
